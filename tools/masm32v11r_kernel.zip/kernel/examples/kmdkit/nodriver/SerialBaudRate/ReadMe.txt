
In this example we deal with existing serial device.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru