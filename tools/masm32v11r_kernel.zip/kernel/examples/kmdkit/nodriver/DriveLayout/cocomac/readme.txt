These macro files is from my package cocomac.
