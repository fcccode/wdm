
Reading MBR from user-mode is easiest thing to do
if you know what device to read from.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru