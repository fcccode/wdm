
This is an example how to allocate memory in kernel mode.
To not allocate it useless we fill it with some system info.

Use KmdManager to register/unregister and start/stop it.
Watch its debug output with the DbgView (www.sysinternals.com) or use SoftICE.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru