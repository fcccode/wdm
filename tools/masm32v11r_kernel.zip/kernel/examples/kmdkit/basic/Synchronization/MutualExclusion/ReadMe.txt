
This is an example how to implement mutual exclusive access to the resource.

Use KmdManager to register/unregister and start/stop it.
Watch its debug output with the DbgView (www.sysinternals.com) or use SoftICE.

______________________
Four-F, four-f@mail.ru