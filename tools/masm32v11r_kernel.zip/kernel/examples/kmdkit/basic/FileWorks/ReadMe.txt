
This is an example how to create, write to, read from and delete the file.

Use KmdManager to register/unregister and start it.
Watch its debug output with the DbgView (www.sysinternals.com) or use SoftICE.

Tested under: Windows 2000, XP and Server 2003.

______________________
Four-F, four-f@mail.ru