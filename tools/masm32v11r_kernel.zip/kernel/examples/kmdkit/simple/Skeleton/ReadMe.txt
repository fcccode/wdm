The skeleton code for a Windows NT Kernel-Mode Device Driver.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru

