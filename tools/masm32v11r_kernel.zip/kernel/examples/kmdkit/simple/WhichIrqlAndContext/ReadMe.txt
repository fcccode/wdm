
This example let you know the IRQL and Process/Thread context
at which the main driver's routines are running.
Use DebugView (www.sysinternals.com) to watch its output.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru