
Demonstrates driver communication with DeviceIoControl,
using buffered method. And how to translate virtual addresses.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru