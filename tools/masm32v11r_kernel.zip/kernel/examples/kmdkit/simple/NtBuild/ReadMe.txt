
Demonstrates driver communication with ReadFile,
using neither method. And how to use SEH in ring0.

Tested on: Windows 2000, XP & Server 2003

______________________
Four-F, four-f@mail.ru